 //"../../inc/dice.h"
#include "jeu.h"



int lancer(FM *J1){
	int nb_alea[1];
	nb_alea[0]=0;
        nb_alea[0] = (rand() % 6) + 1;
        sprintf(&J1->score[0], "%d", nb_alea[0]);
	//printf("%s a fait : %s \n", J1->nom, &J1->score[0]);// aff resultat lancé
	enregistrer(J1);   
    	return nb_alea[0];
}

int affichage_fiche(FM* Joueur) {// retourne Total du Joueur
	int Total= 0;
	printf("\n Fiche de Jeu Yam's de %s \n (les cases remplies avec -1 sont à remplir) ",Joueur->nom);
	printf("\n 1 : %d ",Joueur->un);
	printf("\n 2 : %d", Joueur->deux);
	printf("\n 3 : %d", Joueur->trois);
	printf("\n 4 : %d", Joueur->quattre);
	printf("\n 5 : %d", Joueur->cinq);
	printf("\n 6 : %d", Joueur->six);
	printf("\n Total 1 : %d", Joueur->un +Joueur->deux + Joueur->trois + Joueur->quattre+ Joueur->cinq + Joueur->six);
	Total = Joueur->un +Joueur->deux + Joueur->trois + Joueur->quattre+ Joueur->cinq + Joueur->six;
	if ( Joueur->un +Joueur->deux + Joueur->trois + Joueur->quattre+ Joueur->cinq + Joueur->six >= 63) {
		printf("\n Total 1 + BONUS! : %d",  Joueur->un +Joueur->deux + Joueur->trois + Joueur->quattre+ Joueur->cinq + Joueur->six+35);
		Total =  Joueur->un +Joueur->deux + Joueur->trois + Joueur->quattre+ Joueur->cinq + Joueur->six + 35;
	}
	printf("\n\n full : %d", Joueur->full); 
	printf("\n chance : %d", Joueur->chance); 
	printf("\n brelan : %d", Joueur->brelan); 
	printf("\n carre : %d", Joueur->carre);
	printf("\n yam : %d", Joueur->yam);
	printf("\n Total 2 : %d", Joueur->full+ Joueur->chance + Joueur->brelan + Joueur->carre + Joueur->yam);
	printf("\n\n TOTAL = %d", Total + Joueur->full+ Joueur->chance + Joueur->brelan + Joueur->carre + Joueur->yam);

	return Total + Joueur->full+ Joueur->chance + Joueur->brelan + Joueur->carre + Joueur->yam;

}

void clear_fiche(FM* Joueur){
Joueur->un = -1;
Joueur->deux  = -1;
Joueur->trois = -1 ;
Joueur->quattre = -1;
Joueur->cinq = -1;
Joueur->six = -1;
Joueur->full= -1;
Joueur->chance= -1;
Joueur->brelan= -1;
Joueur->carre= -1;
Joueur->yam= -1;

}

int des_guarder(int de1,int de2,int de3,int de4,int de5){
	int retrait=-1;
	while (retrait != 0) {
		printf("\n quels dé voulez vous relancez? exemple : 1 pour dé1, écrire 0 pour aucun \n  ");
		scanf("%d", &retrait);
		if (retrait == 1) {
			de1 = 0;
		}
		else if (retrait == 2) {
			de2 = 0;
		}
		else if (retrait == 3) {
			de3 = 0;
		}
		else if (retrait == 4) { 
			de4 = 0;
		}
		else if (retrait == 5) { 
			de5 = 0;
		}
	}

	return de1,de2,de3,de4,de5; 

}

int relance(FM *J1,int de1,int de2, int de3,int de4,int de5){

				if (de1 == 0) {
					
					de1 = lancer(J1);
				}
				if (de2 == 0) {
					de2 = lancer(J1);
				}
				if (de3 == 0) {
					de3 = lancer(J1);
				}
				if (de4 == 0) {
					de4 = lancer(J1);
				}
				if (de5 == 0) {
					de5 = lancer(J1);
				}
return de1,de2,de3,de4,de5;
}

void tour_de_jeu(FM *J1) {
	int de1=lancer(J1);
	int de2=lancer(J1);
	int de3 = lancer(J1);
	int de4 = lancer(J1);
	int de5 = lancer(J1);
	//int choix = 0; ??
	printf("votre 1er lancé : %d %d %d %d %d", de1,de2,de3, de4, de5);
	affichage_fiche(J1);
	de1,de2,de3,de4,de5 = des_guarder(de1,de2,de3,de4,de5);
	de1,de2,de3,de4,de5=relance(J1,de1,de2,de3,de4,de5);
	printf("votre 2ème lancé : %d %d %d %d %d", de1, de2, de3, de4, de5);
	de1,de2,de3,de4,de5 = des_guarder(de1,de2,de3,de4,de5);
	de1,de2,de3,de4,de5=relance(J1,de1,de2,de3,de4,de5);
	printf("votre 3ème lancé : %d %d %d %d %d", de1, de2, de3, de4, de5);
}


