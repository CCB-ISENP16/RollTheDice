#include <stdio.h>
#include <time.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>



typedef struct FeuilleMatch {
	char nom[50];
	char score[3];
	int un;
	int deux;
	int trois;
	int quattre; 
	int cinq;
	int six;
	int yam;
	int carre;
	int brelan;
	int chance;
	int full;


}FM;
void clear_fiche(FM* Joueur);
int  des_guarder(int de1,int de2,int de3,int de4,int de5);
int relance(FM *J1, int de1,int de2,int de3,int de4,int de5);
int lancer(FM *J1);
int affichage_fiche(FM* Joueur);
void tour_de_jeu(FM *J1);



